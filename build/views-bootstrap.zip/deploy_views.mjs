import { readdir, readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  AthenaClient,
  GetQueryExecutionCommand,
  StartQueryExecutionCommand,
} from "@aws-sdk/client-athena";
import { GetTableCommand, GlueClient } from "@aws-sdk/client-glue";
import { InvokeCommand, LambdaClient } from "@aws-sdk/client-lambda";

/**
 * Deploys the analytical model from sql/model, the only place where tables and
 * views are defined. The same code runs for the pilot and for every tenant, so
 * a change to a .sql file reaches all of them identically.
 *
 *   tables/  created only when missing (Iceberg tables are never replaced)
 *   views/   always re-created (CREATE OR REPLACE VIEW)
 *
 * Runs at terraform apply, and after every successful Glue load. On a load it
 * then hands off to the SPICE refresh, so SPICE never reads a view that is
 * still being replaced.
 *
 * Also runnable locally with the same files:
 *   GLUE_DATABASE=... ATHENA_WORKGROUP=... WAREHOUSE_PATH=... SQL_DIR=sql/model \
 *     node services/views-bootstrap/src/deploy_views.mjs [--tables-only]
 */

const here = path.dirname(fileURLToPath(import.meta.url));

const athena = new AthenaClient({});
const glue = new GlueClient({});
const lambda = new LambdaClient({});

const required = (name) => {
  const value = process.env[name];
  if (!value) throw new Error(`Missing required environment variable: ${name}`);
  return value;
};

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/** Replaces ${name} markers and refuses to run SQL with an unknown one left. */
export function render(sql, variables) {
  const rendered = sql.replace(/\$\{([a-z_]+)\}/g, (marker, name) => {
    if (!(name in variables)) throw new Error(`Unknown marker ${marker}`);
    return variables[name];
  });

  // Athena runs one statement per query; full-line comments are dropped so
  // DDL always starts with its keyword.
  return rendered
    .split("\n")
    .filter((line) => !line.trim().startsWith("--"))
    .join("\n")
    .trim()
    .replace(/;\s*$/, "");
}

/** Reads <dir>/<kind>/*.sql in name order. Table name comes from the file name. */
export async function loadStatements(sqlDir, kind, variables) {
  const folder = path.join(sqlDir, kind);
  const files = (await readdir(folder)).filter((file) => file.endsWith(".sql")).sort();
  if (files.length === 0) throw new Error(`No SQL files in ${folder}`);

  return Promise.all(
    files.map(async (file) => {
      const match = /^\d+_(.+)\.sql$/.exec(file);
      if (!match) throw new Error(`SQL file must be named NN_<name>.sql: ${file}`);
      const sql = render(await readFile(path.join(folder, file), "utf8"), variables);
      return { file, name: match[1], sql };
    }),
  );
}

async function execute(statement, database, workGroup) {
  const started = await athena.send(
    new StartQueryExecutionCommand({
      QueryString: statement,
      WorkGroup: workGroup,
      QueryExecutionContext: { Database: database },
    }),
  );

  for (let attempt = 0; attempt < 60; attempt += 1) {
    await sleep(2000);
    const execution = await athena.send(
      new GetQueryExecutionCommand({ QueryExecutionId: started.QueryExecutionId }),
    );
    const state = execution.QueryExecution?.Status?.State;

    if (state === "SUCCEEDED") return;
    if (state === "FAILED" || state === "CANCELLED") {
      throw new Error(
        `Athena ${state}: ${execution.QueryExecution?.Status?.StateChangeReason ?? "unknown"}`,
      );
    }
  }

  throw new Error("Athena statement timed out");
}

async function tableExists(database, name) {
  try {
    await glue.send(new GetTableCommand({ DatabaseName: database, Name: name }));
    return true;
  } catch (error) {
    if (error.name === "EntityNotFoundException") return false;
    throw error;
  }
}

/**
 * Any failure stops the deployment. Views over a missing table or an invalid
 * statement are real problems: hiding them would leave SPICE refreshing
 * yesterday's model without anyone noticing.
 */
export async function deployModel({ tablesOnly = false } = {}) {
  const database = required("GLUE_DATABASE");
  const workGroup = required("ATHENA_WORKGROUP");
  const sqlDir = process.env.SQL_DIR ?? path.join(here, "sql");
  const variables = {
    db: database,
    warehouse: required("WAREHOUSE_PATH").replace(/\/+$/, ""),
  };

  const summary = { tablesCreated: [], tablesExisting: [], views: [] };

  for (const table of await loadStatements(sqlDir, "tables", variables)) {
    if (await tableExists(database, table.name)) {
      summary.tablesExisting.push(table.name);
      continue;
    }
    await execute(table.sql, database, workGroup);
    summary.tablesCreated.push(table.name);
  }

  if (!tablesOnly) {
    for (const view of await loadStatements(sqlDir, "views", variables)) {
      await execute(view.sql, database, workGroup);
      summary.views.push(view.name);
    }
  }

  return summary;
}

export const handler = async (event = {}) => {
  const summary = await deployModel();
  console.log(JSON.stringify({ message: "Model deployed", ...summary }));

  // After a Glue load, refresh SPICE only once the views are in place.
  const jobRunId = event?.detail?.jobRunId;
  const refreshFunction = process.env.REFRESH_FUNCTION_NAME;
  if (jobRunId && refreshFunction) {
    await lambda.send(
      new InvokeCommand({
        FunctionName: refreshFunction,
        InvocationType: "Event",
        Payload: Buffer.from(JSON.stringify({ jobRunId, trigger: "glue-load" })),
      }),
    );
    console.log(JSON.stringify({ message: "SPICE refresh requested", jobRunId }));
  }

  return summary;
};

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  deployModel({ tablesOnly: process.argv.includes("--tables-only") })
    .then((summary) => console.log(JSON.stringify(summary, null, 2)))
    .catch((error) => {
      console.error(error);
      process.exitCode = 1;
    });
}
